package org.example;

public record Document(String name){

}
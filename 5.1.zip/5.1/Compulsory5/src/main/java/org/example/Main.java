package org.example;

import com.github.javafaker.Faker;

import java.io.EOFException;
import java.io.IOException; // Pentru IOException
import java.nio.file.Path; // Pentru clasa Path
import java.nio.file.Paths; // Pentru metoda Paths.get()
import java.util.Arrays;
import java.util.List; // Pentru interfața List
import java.util.Scanner;
import java.util.stream.Collectors; // Pentru metoda Collectors.toList()
import java.util.stream.IntStream;


public class Main {
    public static void main(String[] args) throws Exception {
        Faker faker = new Faker();
        Operations o = new Operations();

        Person[] persons = IntStream.rangeClosed(0, 9)
                .mapToObj(i -> new Person(faker.name().lastName(), i))
                .toArray(Person[]::new);
        /*
        try {
            o.makeDir();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
*/
        try {
            o.make(persons);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }


        try{
            o.displayDirectoryContent("/Users/fabian-andreihirjan/Desktop/Path/");
        }catch (IOException e) {
            throw new RuntimeException(e);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        // Restul codului din main
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter person's name: ");
        String personName = scanner.nextLine();
        System.out.println("Enter document's name: ");
        String documentName = scanner.nextLine();

        Person person = new Person(personName, 0); // O luăm de la un ID fictiv pentru moment
        Document document = new Document(documentName);

        try {
            o.addDocumentToPerson(person, document);
        } catch (IOException e) {
            e.printStackTrace(); // sau altă acțiune dorită
        }

    }

}